﻿/*
Programmers: Amritpal Singh, Dhruvanshi Ghiya
File Name: Testing.cs
Project: Logging Server
Solution: Logging Service
Date: 25 Feburary, 2022
Description: It is used for testing purpose only.
*/





using System;

namespace Logging_Server
{
    class Testing
    {

        /*
            Class: Testing
            Description: Solely for testing purposes
       */
        static void Main()
        {
            //Generate the log file and writes the start time of service started
            Logger.GenerateLogFile("-------------------Logging Service Started at " + DateTime.Now);

            //Start process
            Logger.StartLogging();

            //logs the end time when service ended in log file
            Logger.GenerateLogFile("----------------Logging Stopped because Server is stopped at " + DateTime.Now);
        }
    }
}
